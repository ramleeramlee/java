package 배열복습;

public class 이차원배열프린트2 {

	public static void main(String[] args) {
		//꼭 하고 싶은 것 9가지를 작성해서, 전체 프린트
		String[][] s = {
				{"","",""},
				{"","",""},
				{"","",""}
		}; //전체를 프린트!
		
	}
}
